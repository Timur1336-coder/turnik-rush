package com.turnikrush.game

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.content.Context
import android.content.SharedPreferences
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        setContentView(GameView(this))
    }
}

private data class Skin(val name: String, val shirt: Int, val pants: Int, val price: Int, val subtitle: String)

private class GameView(ctx: Context) : View(ctx) {
    private val prefs: SharedPreferences = ctx.getSharedPreferences("turnik_rush", Context.MODE_PRIVATE)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val skins = listOf(
        Skin("СТАРТЕР", Color.rgb(34,190,220), Color.rgb(32,42,62), 0, "Базовый образ"),
        Skin("ШТУРМОВИК", Color.rgb(42,72,54), Color.rgb(34,42,35), 150, "Тактическая форма"),
        Skin("ЗОЛОТОЙ", Color.rgb(255,184,30), Color.rgb(219,153,14), 300, "Золотая куртка и штаны"),
        Skin("ПАРКУР", Color.rgb(236,75,90), Color.rgb(27,30,42), 200, "Городской стиль"),
        Skin("НЕОН", Color.rgb(175,75,255), Color.rgb(20,230,180), 250, "Неоновый комплект"),
        Skin("СНЕГ", Color.rgb(240,245,250), Color.rgb(165,188,210), 180, "Светлый образ"),
        Skin("АЛЫЙ", Color.rgb(185,24,45), Color.rgb(40,42,55), 160, "Красно-чёрный"),
        Skin("ТЕНЬ", Color.rgb(42,45,58), Color.rgb(15,17,24), 280, "Тёмный образ")
    )
    private var screen = 0 // 0 menu, 1 game, 2 wardrobe, 3 over
    private var skinIndex = prefs.getInt("skin", 0).coerceIn(0, skins.lastIndex)
    private var coins = prefs.getInt("coins", 0)
    private var best = prefs.getInt("best", 0)
    private var score = 0
    private var x = 0f
    private var y = 0f
    private var swing = 0f
    private var falling = false
    private var lastTime = System.nanoTime()
    private var message = ""
    private var barXs = mutableListOf<Float>()
    private var barYs = mutableListOf<Float>()
    private var barIndex = 0
    private var unlocked = mutableSetOf(0)
    private val bgTop = Color.rgb(14, 22, 42)
    private val bgBottom = Color.rgb(39, 54, 83)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        drawBackground(c, w, h)
        when (screen) {
            0 -> drawMenu(c, w, h)
            1 -> { updateGame(w, h); drawGame(c, w, h); postInvalidateOnAnimation() }
            2 -> drawWardrobe(c, w, h)
            else -> drawGameOver(c, w, h)
        }
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        c.drawColor(bgTop)
        p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, bgTop, bgBottom, android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        p.color = Color.argb(30, 255,255,255); p.strokeWidth = 1f
        var xx = 0f
        while (xx < w) { c.drawLine(xx, 0f, xx, h, p); xx += 42f }
        var yy = 0f
        while (yy < h) { c.drawLine(0f, yy, w, yy, p); yy += 42f }
        p.color = Color.argb(20, 35, 225, 255)
        c.drawCircle(w * .82f, h * .15f, h * .24f, p)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Color.WHITE, bold: Boolean = false, center: Boolean = true) {
        p.color = color; p.textSize = size; p.typeface = if (bold) android.graphics.Typeface.create("sans-serif-black", 0) else android.graphics.Typeface.create("sans-serif-medium", 0); p.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        c.drawText(s, x, y, p)
    }
    private fun panel(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int = Color.argb(220, 24, 34, 56)) {
        p.color = color; c.drawRoundRect(RectF(x,y,x+w,y+h), 22f,22f,p)
        p.color = Color.argb(100, 100, 220, 255); p.style = Paint.Style.STROKE; p.strokeWidth = 2f; c.drawRoundRect(RectF(x,y,x+w,y+h),22f,22f,p); p.style = Paint.Style.FILL
    }
    private fun button(c: Canvas, s: String, x: Float, y: Float, w: Float, h: Float, primary: Boolean = false) {
        p.color = if (primary) Color.rgb(255,177,36) else Color.rgb(45,64,96)
        c.drawRoundRect(RectF(x,y,x+w,y+h),18f,18f,p)
        text(c, s, x+w/2, y+h/2+9f, min(27f,h*.35f), if(primary) Color.rgb(25,31,46) else Color.WHITE, true)
    }
    private fun drawMenu(c: Canvas, w: Float, h: Float) {
        text(c, "TURNIK", w/2, h*.20f, h*.13f, Color.WHITE, true)
        text(c, "RUSH", w/2, h*.31f, h*.13f, Color.rgb(255,184,35), true)
        text(c, "КАЧАЙСЯ • ПРЫГАЙ • ХВАТАЙСЯ", w/2, h*.39f, h*.035f, Color.rgb(190,211,239), true)
        drawCharacter(c,w*.24f,h*.64f,h*.18f,0f)
        panel(c,w*.48f,h*.44f,w*.39f,h*.43f)
        button(c,"ИГРАТЬ",w*.52f,h*.49f,w*.31f,h*.09f,true)
        button(c,"ГАРДЕРОБ",w*.52f,h*.61f,w*.31f,h*.09f)
        button(c,"ОБ ИГРЕ",w*.52f,h*.73f,w*.31f,h*.09f)
        text(c,"РЕКОРД: $best   •   МОНЕТЫ: $coins",w/2,h*.94f,h*.035f,Color.rgb(203,218,242),true)
    }
    private fun startGame(w: Float, h: Float) {
        screen = 1; score = 0; x = w*.18f; y = h*.45f; swing = 0f; falling = false; barIndex = 0
        barXs = mutableListOf(w*.18f,w*.43f,w*.68f,w*.94f)
        barYs = mutableListOf(h*.29f,h*.35f,h*.24f,h*.33f)
        lastTime = System.nanoTime()
        invalidate()
    }
    private fun updateGame(w: Float, h: Float) {
        val now = System.nanoTime(); val dt = ((now-lastTime)/1e9).toFloat().coerceIn(0f,.04f); lastTime = now
        if (falling) { y += h*.95f*dt; if (y > h*1.1f) screen = 3; return }
        swing += dt*3.4f
        val cameraOffset = maxOf(0f, (barIndex - 1) * w * .25f)
        x = barXs[barIndex] - cameraOffset + sin(swing)*w*.025f
        y = barYs[barIndex] + h*.12f + cos(swing)*h*.018f
    }
    private fun drawGame(c: Canvas, w: Float, h: Float) {
        // distant skyline
        p.color = Color.argb(100,8,13,26)
        for (i in 0..12) { val bw = w*.045f; val bx = i*w/12f; c.drawRect(bx,h*.53f,bx+bw,h*.82f,p) }
        val cameraOffset = maxOf(0f, (barIndex - 1) * w * .25f)
        for (i in barXs.indices) {
            val bx = barXs[i] - cameraOffset; val by = barYs[i]
            if (bx > -w*.15f && bx < w*1.15f) {
                p.color = Color.rgb(76,91,117); p.strokeWidth = h*.012f; c.drawLine(bx-w*.09f,by,bx+w*.09f,by,p)
                p.color = Color.rgb(255,184,35); c.drawCircle(bx,by,h*.012f,p)
            }
        }
        drawCharacter(c,x,y,h*.16f,swing)
        panel(c, w*.025f,h*.035f,w*.25f,h*.10f)
        text(c,"ДИСТАНЦИЯ: $score",w*.15f,h*.10f,h*.035f,Color.WHITE,true)
        panel(c,w*.70f,h*.035f,w*.27f,h*.10f)
        text(c,"КАСАНИЕ = ПРЫЖОК",w*.835f,h*.10f,h*.028f,Color.WHITE,true)
        text(c,"Коснись экрана, чтобы схватиться за следующий турник",w/2,h*.94f,h*.032f,Color.rgb(216,230,249),true)
        if (falling) text(c,"ПАДАЕШЬ!",w/2,h*.7f,h*.08f,Color.rgb(255,90,100),true)
    }
    private fun drawCharacter(c: Canvas, cx: Float, cy: Float, size: Float, phase: Float) {
        val s = size
        val skin = skins[skinIndex]
        val angle = sin(phase)*.28f
        c.save(); c.rotate(angle*57f,cx,cy)
        // head
        p.color = Color.rgb(225,177,139); c.drawCircle(cx,cy-s*.39f,s*.115f,p)
        // hair
        p.color = Color.rgb(44,31,28); c.drawArc(RectF(cx-s*.12f,cy-s*.52f,cx+s*.12f,cy-s*.29f),180f,180f,true,p)
        // torso and legs
        p.color = skin.shirt; c.drawRoundRect(RectF(cx-s*.10f,cy-s*.27f,cx+s*.10f,cy+s*.05f),s*.05f,s*.05f,p)
        p.color = skin.pants
        c.drawRoundRect(RectF(cx-s*.085f,cy+s*.02f,cx-s*.005f,cy+s*.27f),s*.03f,s*.03f,p)
        c.drawRoundRect(RectF(cx+s*.005f,cy+s*.02f,cx+s*.085f,cy+s*.27f),s*.03f,s*.03f,p)
        // arms reaching up to bar
        p.color = Color.rgb(225,177,139); p.strokeWidth=s*.055f; p.strokeCap=Paint.Cap.ROUND
        c.drawLine(cx-s*.07f,cy-s*.22f,cx-s*.19f,cy-s*.48f,p); c.drawLine(cx+s*.07f,cy-s*.22f,cx+s*.19f,cy-s*.48f,p)
        c.drawCircle(cx-s*.19f,cy-s*.48f,s*.035f,p); c.drawCircle(cx+s*.19f,cy-s*.48f,s*.035f,p)
        c.restore()
    }
    private fun drawWardrobe(c: Canvas, w: Float, h: Float) {
        text(c,"ГАРДЕРОБ",w/2,h*.13f,h*.09f,Color.WHITE,true)
        text(c,"Монеты: $coins",w*.85f,h*.10f,h*.035f,Color.rgb(255,195,52),true)
        val skin = skins[skinIndex]
        panel(c,w*.08f,h*.22f,w*.84f,h*.55f)
        drawCharacter(c,w*.28f,h*.51f,h*.33f,0f)
        text(c,skin.name,w*.60f,h*.38f,h*.07f,Color.rgb(255,190,45),true)
        text(c,skin.subtitle,w*.60f,h*.46f,h*.033f,Color.rgb(205,220,241),true)
        text(c,"Цена: ${skin.price} монет",w*.60f,h*.54f,h*.035f,Color.WHITE,true)
        button(c,"◀",w*.43f,h*.61f,w*.08f,h*.09f)
        button(c,"ВЫБРАТЬ / КУПИТЬ",w*.53f,h*.61f,w*.25f,h*.09f,true)
        button(c,"НАЗАД",w*.04f,h*.83f,w*.20f,h*.09f)
        text(c,"Скины открываются за монеты, заработанные в забегах",w*.60f,h*.83f,h*.028f,Color.rgb(205,220,241),true)
    }
    private fun drawGameOver(c: Canvas, w: Float, h: Float) {
        panel(c,w*.23f,h*.18f,w*.54f,h*.64f)
        text(c,"ЗАБЕГ ОКОНЧЕН",w/2,h*.32f,h*.08f,Color.rgb(255,95,107),true)
        text(c,"Дистанция: $score",w/2,h*.44f,h*.05f,Color.WHITE,true)
        text(c,"Рекорд: $best",w/2,h*.52f,h*.04f,Color.rgb(255,190,45),true)
        button(c,"ЕЩЁ РАЗ",w*.31f,h*.60f,w*.38f,h*.09f,true)
        button(c,"В МЕНЮ",w*.31f,h*.71f,w*.38f,h*.08f)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val tx=e.x; val ty=e.y; val w=width.toFloat(); val h=height.toFloat()
        when(screen) {
            0 -> when {
                tx>w*.48f && ty in h*.44f..h*.59f -> startGame(w,h)
                tx>w*.48f && ty in h*.60f..h*.72f -> screen=2
                tx>w*.48f && ty in h*.72f..h*.88f -> { message="Один точный прыжок за раз!"; invalidate() }
            }
            1 -> {
                if (!falling) {
                    if (barIndex < barXs.lastIndex) {
                        barIndex++; score += 10; coins += 5
                        if (barIndex == barXs.lastIndex) {
                            barXs.add(barXs.last() + w*.25f)
                            barYs.add(h*(.22f+Random.nextFloat()*.16f))
                        }
                    } else falling=true
                    if (score>best) best=score
                    prefs.edit().putInt("coins",coins).putInt("best",best).apply()
                }
                invalidate()
            }
            2 -> when {
                tx<w*.25f && ty>h*.78f -> screen=0
                tx in w*.42f..w*.53f && ty in h*.59f..h*.75f -> skinIndex=(skinIndex-1+skins.size)%skins.size
                tx in w*.52f..w*.81f && ty in h*.58f..h*.75f -> {
                    val s=skins[skinIndex]
                    if (s.price==0 || prefs.getBoolean("skin_${skinIndex}",false)) { prefs.edit().putInt("skin",skinIndex).apply() }
                    else if(coins>=s.price) { coins-=s.price; prefs.edit().putBoolean("skin_${skinIndex}",true).putInt("coins",coins).putInt("skin",skinIndex).apply() }
                }
            }
            else -> when {
                ty in h*.58f..h*.70f -> startGame(w,h)
                ty in h*.70f..h*.83f -> screen=0
            }
        }
        invalidate(); return true
    }
}
